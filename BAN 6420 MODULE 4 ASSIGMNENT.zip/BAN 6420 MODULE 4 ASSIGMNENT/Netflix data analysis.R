#Load the package for reading excel files
library(readxl)

#Load data visualization library
library(ggplot2)

# Read the Excel file
netflix_df <- read_excel("C:/Users/DELL/Desktop/IJ/Data Exploration and Analysis/cleaned_netflix.xlsx")

#check the first few rows 
head(netflix_df)

# #Distribution of the top 2 countries where shows were released
top_countries <- head(sort(table(netflix_df$country), decreasing = TRUE), 2)
print(top_countries)

# Convert the table to a data frame for plotting
top_countries_df <- as.data.frame(top_countries)

# Rename columns for clarity 
colnames(top_countries_df) <- c("country", "count")
head(top_countries_df)

#Visualizing the insight generated
ggplot(data = top_countries_df, 
       aes(x = country, y = count)) + geom_bar(stat = "identity", fill = "green") + 
  ggtitle("Top 5 Countries Where Shows Were Released") + theme_minimal()

